create table invoice(
	invoice_id int8 primary key,
	customer_id int8 not null,
	invoice_date date not null,
	billing_address varchar not null,
	billing_city varchar not null,
	billing_state varchar not null,
	billing_country varchar not null,
	billing_postal_code varchar not null,
	total numeric not null
)

copy invoice(invoice_id,customer_id ,invoice_date ,billing_address,billing_city,billing_state,billing_country ,billing_postal_code,total)
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\invoice.csv'
delimiter ','
csv header;

select * from invoice