create table album(
album_id int8 primary key,
	title varchar not null,
	artist_id int8 not null
)

copy album(album_id,title,artist_id)
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\album.csv'
delimiter ','
csv header;

select * from album