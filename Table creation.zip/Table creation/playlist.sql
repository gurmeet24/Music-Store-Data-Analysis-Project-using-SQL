create table playlist(
 playlist_id int8 primary key,
	name varchar not null
)

copy playlist(playlist_id,name)
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\playlist.csv'
delimiter ','
csv header;

select * from playlist