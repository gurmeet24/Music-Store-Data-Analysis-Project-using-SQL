CREATE TABLE customer (
    customer_id INT8 PRIMARY KEY,
    first_name VARCHAR NOT NULL,
    last_name VARCHAR,
    company VARCHAR,
    address VARCHAR,
    city VARCHAR,
    state VARCHAR,
    country VARCHAR,
    postal_code VARCHAR,
    phone VARCHAR(20),
    fax VARCHAR(20), -- Adjust the length as needed
    email VARCHAR,
    support_rep_id NUMERIC
);


copy customer(customer_id,first_name,last_name,company,address,city,state,country ,postal_code,phone,fax,email,support_rep_id)
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\customer.csv'
delimiter ','
csv header;


select * from customer