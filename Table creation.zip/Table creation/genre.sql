create table genre(
 genre_id int8 primary key,
	name varchar not null
)

copy genre(genre_id,name)
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\genre.csv'
delimiter ','
csv header;

select * from genre