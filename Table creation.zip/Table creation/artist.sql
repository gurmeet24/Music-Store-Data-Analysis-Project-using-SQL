create table artist(
artist_id int8 primary key,
	name varchar not null
)

copy artist(artist_id,name)
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\artist.csv'
delimiter ','
csv header;

select * from artist