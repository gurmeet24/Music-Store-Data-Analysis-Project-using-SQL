create table track(
track_id int8 primary key,
	name varchar not null,
	album_id int8 ,
	media_type_id int8 not null,
	genre_id int8 not null,
	composer varchar,
	milliseconds bigint, 
	bytes bigint,
	unit_price numeric

)

copy track(track_id,name,album_id,media_type_id,genre_id,composer,milliseconds,bytes,unit_price )
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\track.csv'
delimiter ','
csv header;

select * from track