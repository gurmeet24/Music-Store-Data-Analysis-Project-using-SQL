create table media_type(
media_type_id int8 primary key,
	name varchar not null
)

copy media_type(media_type_id,name)
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\media_type.csv'
delimiter ','
csv header;

select * from media_type