create table invoice_line(
invoice_line_id int8 primary key,
	invoice_id int8 not  null,
	track_id int8 not null,
	unit_price numeric not null,
	quantity int8 not null
)

copy invoice_line(invoice_line_id,invoice_id,track_id,unit_price,quantity)
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\invoice_line.csv'
delimiter ','
csv header;

select * from invoice_line