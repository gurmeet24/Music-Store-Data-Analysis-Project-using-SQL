create table employee(
	employee_id int8 primary key,
	last_name varchar ,
	first_name varchar,
	title varchar ,
	reports_to numeric ,
	levels varchar,
	birthdate date ,
	hire_date date ,
	address varchar,
	city varchar,
	state varchar,
	country varchar,
	postal_code varchar,
	phone varchar ,
	fax varchar,
	email varchar
)

SET datestyle = 'ISO, DMY';

copy employee(employee_id,last_name,first_name,title,reports_to,levels,birthdate,hire_date,address,city,state,country,postal_code,phone,fax,email)
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\employee.csv'
delimiter ','
csv header;

select * from employee
