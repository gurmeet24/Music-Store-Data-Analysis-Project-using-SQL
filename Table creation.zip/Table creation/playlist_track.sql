create table playlist_track(
 playlist_id int8 ,
	track_id int8 primary key
)

copy playlist_track(playlist_id,track_id)
from 'C:\Users\Asus\Downloads\Skills\SQL\Music store data analysis\playlist_track.csv'
delimiter ','
csv header;

select * from playlist_track